#pragma once

class EditmodeUpdatable
{
protected:
	bool updateInEditmode_ = false;
};