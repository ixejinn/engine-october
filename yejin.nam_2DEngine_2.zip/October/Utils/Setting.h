#pragma once

const unsigned int WINDOW_WIDTH = 1500;
const unsigned int WINDOW_HEIGHT = 1000;