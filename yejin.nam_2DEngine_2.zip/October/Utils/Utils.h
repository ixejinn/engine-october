#pragma once

enum Direction
{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	STOP
};